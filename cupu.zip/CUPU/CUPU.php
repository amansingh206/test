<?php
/*
Plugin Name: Custom Profile Picture Upload
Description: Allows users to upload their profile picture and display it anywhere on the site.
Version: 1.0
Author: Your Name
*/

// Enqueue scripts and styles for the profile picture upload form
function custom_profile_pic_upload_scripts() {
    // Enqueue CSS
    wp_enqueue_style('custom-profile-pic-upload-style', plugin_dir_url(__FILE__) . 'css/style.css');
    
    // Enqueue JS
    wp_enqueue_script('custom-profile-pic-upload-script', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), '', true);
}
add_action('wp_enqueue_scripts', 'custom_profile_pic_upload_scripts');

// Display the profile picture upload form
function custom_profile_pic_upload_form() {
    ob_start();
    ?>
    <form id="custom-profile-pic-upload-form" method="post" enctype="multipart/form-data">
        <input type="file" name="profile_picture" id="profile_picture">
        <input type="submit" name="submit" value="Upload Profile Picture">
        <?php wp_nonce_field('custom-profile-pic-upload', 'custom-profile-pic-upload-nonce'); ?>
    </form>
    <?php
    return ob_get_clean();
}

// Handle profile picture upload and save it
function handle_profile_pic_upload() {
    if (isset($_POST['submit']) && isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture']['name'])) {
        if (wp_verify_nonce($_POST['custom-profile-pic-upload-nonce'], 'custom-profile-pic-upload')) {
            $upload_dir = wp_upload_dir();
            $upload_path = $upload_dir['path'];
            $file_name = $_FILES['profile_picture']['name'];
            $file_tmp = $_FILES['profile_picture']['tmp_name'];

            // Move the uploaded file to the upload directory
            if (move_uploaded_file($file_tmp, $upload_path . '/' . $file_name)) {
                // Save the file path to user meta
                update_user_meta(get_current_user_id(), 'profile_picture', $upload_dir['url'] . '/' . $file_name);
                echo 'Profile picture uploaded successfully.';
            } else {
                echo 'Error uploading profile picture.';
            }
        }
    }
}
add_action('init', 'handle_profile_pic_upload');

// Shortcode to display the profile picture
function display_profile_picture_shortcode() {
    $profile_picture = get_user_meta(get_current_user_id(), 'profile_picture', true);
    if ($profile_picture) {
        return '<img src="' . esc_url($profile_picture) . '" alt="Profile Picture">';
    } else {
        return 'No profile picture uploaded.';
    }
}
add_shortcode('display_profile_picture', 'display_profile_picture_shortcode');

// JavaScript code for client-side validation
?>
<script>
jQuery(document).ready(function($) {
    // Validate profile picture upload form before submission
    $('#custom-profile-pic-upload-form').submit(function(event) {
        var profilePictureInput = $('#profile_picture');
        var profilePictureValue = profilePictureInput.val();

        // Check if a file is selected
        if (profilePictureValue === '') {
            alert('Please select a profile picture.');
            event.preventDefault(); // Prevent form submission
        }
    });
});
</script>
